---
name: python-android-apk
description: >
  Package an existing Python library or tool as an Android APK with a real
  CPython inside it, using Chaquopy and a WebView front end — project
  skeleton, dependency feasibility check, build sequence, CI, and optional
  Cython compilation of the parts you do not want shipped as readable source.
  Use this skill whenever someone wants a Python program to run on a phone,
  says "turn this into an Android app", "make an APK", "run this on my
  phone", "package it for Android", or asks about Chaquopy, BeeWare, Kivy,
  buildozer, embedding Python on Android, bridging a WebView to Python, or
  cross-compiling Python extensions for Android; and whenever an Android
  Python build is failing — pip inside Gradle, wheel tags, ABI mismatches,
  NDK toolchains — or someone asks whether an APK exposes its Python source.
  Reach for it before hand-rolling Gradle files or assuming a dependency will
  be available.
---

# Shipping a Python library as an Android APK

The approach here: **Chaquopy** puts a real CPython (plus binary wheels for
numpy/scipy/pillow/…) inside the APK, and a **WebView** renders the UI while
your Python does the work behind a one-function bridge. Everything runs
locally; nothing is fetched at runtime; the app can hold **zero permissions**.

It suits a computational library with a form-and-results interface — a
solver, a simulator, a calculator, a data tool — where the Python is the
product and the UI is a means of driving it. It is a poor fit for anything
that wants native widgets, background services, or a 60 fps canvas.

Two properties make it worth the effort, and both come from the same choice:
put all the logic in Python, behind one entry point. The Kotlin file stays
about eighty lines and never changes again, and your existing test suite
still covers the app, because the app *is* the library.

> The specifics below — versions, layouts, failure modes — were distilled
> from a scientific-simulation app actually built and shipped this way. Where
> a number is stated it was measured; where something is uncertain it says so.

## Step 0 — the feasibility gate, before anything else

**Check your dependencies first.** This is where these projects die, and it
takes ten minutes rather than the two days you would otherwise spend building
a project around a package that cannot be installed.

Chaquopy runs pure-Python packages from PyPI unchanged. Anything with
compiled extensions must exist as an Android wheel in **Chaquopy's own
repository** — you cannot install numpy from PyPI here — and that repository
lags PyPI, both in package coverage and in which Python versions it covers.
Your usable Python version is therefore decided by your heaviest binary
dependency, not by preference.

`references/toolchain-and-versions.md` gives the procedure: how to check what
exists for which Python, what to do when a dependency is missing, and the
version set that must move together. **Do that first**, and if a hard
dependency is not available, say so and stop — a plan that assumes it will
appear is not a plan.

## Step 1 — the skeleton

`assets/skeleton/` is a complete, commented project: Gradle files, a
permission-free manifest, `MainActivity.kt`, a bridge module, a page that
talks to it, and the test file that keeps the two in step. Copy it in and
rename `mylib` / `com.example.myapp` throughout.

```
your-project/
├── pyproject.toml
├── src/mylib/
│   ├── __init__.py
│   └── appbridge.py          <- assets/skeleton/appbridge.py
├── tests/test_appbridge.py   <- assets/skeleton/test_appbridge.py
└── android/
    ├── settings.gradle.kts
    ├── build.gradle.kts
    └── app/
        ├── build.gradle.kts
        ├── pysrc/            <- the sdist or wheels go here (step 2)
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/example/myapp/MainActivity.kt
            └── assets/www/index.html
```

`references/project-setup.md` explains the bridge contract, the threading
model, and why each piece is shaped the way it is. Read it before designing
your own bridge; several of its constraints are not discoverable from the
Chaquopy docs.

The one rule to carry into every later change: **a bridge method with no
caller is half a feature.** An entry in the registry that no page renders
looks tested and does nothing. The skeleton's `test_appbridge.py` fails in
both directions from text alone — no browser, no emulator, milliseconds.

## Step 2 — build

Two commands from the project root, given Java 17, the matching Python, and
an Android SDK:

```bash
python -m build --sdist --outdir android/app/pysrc .
gradle -p android :app:assembleDebug
# -> android/app/build/outputs/apk/debug/app-debug.apk
```

The sdist is not a formality. `android/app/pysrc/` is where Chaquopy's pip
finds your package, and the Gradle config in the skeleton refuses to guess:
with nothing there it fails with that exact command in the message. It is an
sdist rather than `install("../..")` because a directory install makes the
whole repository an input of the pip task — and the Gradle project sits
inside that repository, so every Android task's output lands inside the pip
task's input and Gradle 8's validation rejects the build.

Rebuild the sdist whenever your Python changes. Gradle cannot see through it,
so a stale sdist silently ships old code — the most common "my fix didn't do
anything" on this stack.

## Step 3 — verify what you actually built

```bash
python scripts/inspect_apk.py app-debug.apk
```

It walks into Chaquopy's payload archives inside the APK and reports which
Python packages shipped and whether each is source or native. Use it to
answer "did my code get in", "is this the build I think it is", and "how
readable is my source in here" — none of which the build log tells you.

What CI cannot tell you, and a claim of "verified" should not imply: whether
the app *runs*. Sideload it and do one real calculation. Gesture feel,
display cutouts and safe-area insets are device-only too.

## Step 4 (optional) — compile the parts you care about

`.pyc` in an APK gives back function names, line numbers and whole
docstrings to anyone who runs `strings`. If that matters:

```bash
python scripts/android_wheel.py --package mylib --compile core,solvers \
    --abi arm64-v8a --ndk "$ANDROID_NDK_HOME"
```

This cythonises the named subpackages and cross-compiles them against
Chaquopy's Android CPython, producing one wheel per ABI that drops into the
same `pysrc/`. `--host` runs the whole path with your own compiler and no
NDK, which is how to test changes to it.

**Already have a working interpreted APK and only want this part?** Then steps
0–3 are behind you, and `references/native-compile.md` has the entry point for
exactly that — *Adding this to a build you already have*. The short version:
one change to your Gradle pip block so wheels resolve by tag, and everything
else is new commands. The Gradle task, manifest, Kotlin and page do not move.

Read `references/native-compile.md` before promising anyone protection from
it. In short: it raises the cost of reading your *algorithms* from "unzip and
read" to "disassemble", and changes nothing about your WebView assets, your
uncompiled modules, or literal constants — which survive in the constant pool
and are findable exactly.

If you ship both builds from one CI run, gate them:

```bash
python scripts/inspect_apk.py compiled.apk --package mylib --native core,solvers
python scripts/inspect_apk.py interpreted.apk --package mylib --pure core,solvers
```

Without that gate the realistic failure — the second build reusing the first's
pip output, so both APKs are the interpreted one — is invisible.

## When it breaks

`references/traps.md` lists the failure modes this stack actually produces,
each with the symptom you see first. Most of them do not point at their
cause: a wheel installed by path, an sdist left beside the wheels, a
`cythonize` flag that is not real and fails silently, an `[hidden]` overlay
that keeps swallowing every tap, a matplotlib import that dies on a read-only
cache directory. Read the symptom column before theorising.

## References

| file | read it when |
|---|---|
| `references/toolchain-and-versions.md` | before you start, and before bumping anything |
| `references/project-setup.md` | wiring the bridge, the page, and the Gradle config |
| `references/native-compile.md` | deciding whether to compile, and what to claim |
| `references/traps.md` | something is wrong |
