"""Tests for the bridge, running on a laptop with no Android anywhere.

This file is the reason the bridge is shaped the way it is.  Every method the
phone can reach is reachable here, so the phone-only work shrinks to "does the
UI render it" -- which is a much smaller thing to verify by hand.

The last test is the one that keeps paying: it compares the bridge's method
registry against the page's JavaScript as text.  No browser, no emulator, a
few milliseconds, and it catches the drift that is otherwise invisible from
either file alone -- a method with no caller, or a call to a method that no
longer exists.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

from mylib import appbridge

WWW = Path(__file__).resolve().parents[1] / "android/app/src/main/assets/www"


def ok(method: str, **args):
    """Call as the page does, assert success, return the value."""
    reply = json.loads(appbridge.call(method, json.dumps(args)))
    assert reply["ok"], reply.get("traceback", reply.get("error"))
    return reply["value"]


def test_version_round_trips():
    v = ok("version")
    assert v["python"].startswith("3.")


def test_compute_returns_the_libraries_answer():
    import mylib
    assert ok("compute", x=5)["result"] == mylib.solve(5)


@pytest.mark.parametrize("method, args", [
    ("no_such_method", {}),
    ("compute", {"x": "not a number"}),
    ("compute", {"unexpected_kwarg": 1}),
])
def test_failures_come_back_in_the_envelope(method, args):
    """Never an exception across the bridge: Kotlin would see a bare Java
    error with none of the Python detail in it."""
    reply = json.loads(appbridge.call(method, json.dumps(args)))
    assert reply["ok"] is False
    assert reply["error"]
    assert "Traceback" in reply["traceback"]


def test_bad_json_is_an_envelope_too():
    reply = json.loads(appbridge.call("compute", "{not json"))
    assert reply["ok"] is False


def test_every_method_has_a_caller_and_every_caller_has_a_method():
    """The anti-drift test.  Break it deliberately once -- add a method and
    run this -- to confirm it actually fails; a regex that matches nothing
    passes every assertion in it, which is a failure mode this exact kind of
    test has had before."""
    js = (WWW / "index.html").read_text(encoding="utf-8")
    called = set(re.findall(r"""\bcall\(\s*["']([A-Za-z_]\w*)["']""", js))
    assert called, "the regex found no call sites at all -- it is wrong"

    registered = set(appbridge._METHODS)
    assert called <= registered, f"page calls missing methods: {called - registered}"
    assert registered <= called, f"methods no page renders: {registered - called}"
