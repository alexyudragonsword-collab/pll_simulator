"""The one entry point the Android app calls.  Drop this in as ``mylib/appbridge.py``.

Everything the app can do goes through :func:`call`, which takes two strings
and returns a string.  That narrowness is the point:

* **It is testable without Android.**  The whole contract is JSON in, JSON out,
  so a plain pytest exercises every method the phone can reach, on a laptop, in
  milliseconds.  A bridge whose only test is "install the APK and tap around"
  is a bridge nobody tests.
* **One error path.**  Every failure -- a bad method name, bad arguments, a
  bug in your library -- comes back in the same envelope, so the page needs one
  branch rather than a taxonomy.
* **Kotlin stays dumb.**  Adding a feature means adding a function here and a
  render there, never touching Java, Gradle, or the emulator.

The one rule worth stating: **a method with no caller is half a feature.**  An
entry in ``_METHODS`` that no page renders looks tested and does nothing.  Wire
the UI in the same change, and consider a test that walks ``_METHODS`` against
the page's JavaScript so the two cannot drift silently -- text comparison, no
browser needed.
"""
from __future__ import annotations

import base64
import io
import json
import traceback
from typing import Any, Callable

# ---------------------------------------------------------------- registry

_METHODS: dict[str, Callable[..., Any]] = {}


def method(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Expose a function to the page under its own name."""
    _METHODS[fn.__name__] = fn
    return fn


def call(name: str, args_json: str) -> str:
    """The single entry point.  Never raises: the page gets an envelope.

    Kotlin calls this on a background thread and hands the returned string
    straight to JavaScript, so anything escaping here would surface as an
    opaque Java exception with none of the Python traceback in it.
    """
    try:
        fn = _METHODS.get(name)
        if fn is None:
            known = ", ".join(sorted(_METHODS))
            raise KeyError(f"no such method {name!r}; known: {known}")
        args = json.loads(args_json) if args_json else {}
        if not isinstance(args, dict):
            raise TypeError("arguments must be a JSON object")
        return json.dumps({"ok": True, "value": fn(**args)})
    except Exception as exc:                       # noqa: BLE001 -- see above
        return json.dumps({
            "ok": False,
            "error": f"{type(exc).__name__}: {exc}",
            # keep the traceback: the alternative is debugging a phone by
            # guessing, and it costs nothing until something breaks
            "traceback": traceback.format_exc(),
        })


# ------------------------------------------------------------------ helpers

def png(fig, dpi: int = 130) -> str:
    """A matplotlib figure as a base64 PNG, ready for an <img src>.

    Note the absence of ``bbox_inches="tight"``: it silently changes the
    figure's extent, so any pixel coordinates you also send the page (axes
    rectangles, cursor data) would describe a different image than the one
    displayed.  Set the figure size instead.
    """
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi)
    import matplotlib.pyplot as plt
    plt.close(fig)                      # or the phone leaks a figure per call
    return base64.b64encode(buf.getvalue()).decode("ascii")


# ------------------------------------------------------------------ methods
# Replace these with your own.  Keep them boring: parse, delegate to the real
# library, return JSON-serialisable data.  Business logic that lives here is
# logic your existing test suite does not cover.

@method
def version() -> dict[str, str]:
    """Cheap round trip the page can call on boot to prove the bridge works."""
    import platform
    import mylib
    return {"lib": getattr(mylib, "__version__", "unknown"),
            "python": platform.python_version()}


@method
def compute(x: float = 1.0) -> dict[str, Any]:
    import mylib
    return {"result": mylib.solve(x)}
