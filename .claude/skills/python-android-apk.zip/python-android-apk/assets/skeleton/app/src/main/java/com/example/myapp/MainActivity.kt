package com.example.myapp

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.system.Os
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * A WebView shell around a Python module that exposes one `call` function.
 *
 * The whole Kotlin surface is this file, on purpose.  Everything that is
 * actually your application -- the computation, the validation, the shape of
 * every reply -- stays in Python, where it is testable on a laptop without an
 * emulator.  Kotlin's job is to start the interpreter, hand strings across,
 * and get out of the way.
 */
class MainActivity : Activity() {

    /**
     * One lane, deliberately.  The Python side is ordinary library code with
     * no locking; a single-threaded executor makes "one call at a time" a
     * property of the app rather than a discipline every caller must keep.
     * It also serialises the first call's import cost (several seconds on a
     * phone for a scientific stack) instead of paying it N times.
     */
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var web: WebView
    private var bridge: PyObject? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) {
            // Any library that writes a cache on first import needs a writable
            // HOME-ish directory, and this must happen BEFORE Python.start().
            // matplotlib is the usual casualty: it builds a font cache on
            // import and dies on a read-only config dir.  Delete these two
            // lines if nothing you import needs them -- but know why.
            val cache = filesDir.resolve("pycache").apply { mkdirs() }
            Os.setenv("MPLCONFIGDIR", cache.path, true)
            Os.setenv("XDG_CACHE_HOME", cache.path, true)
            Python.start(AndroidPlatform(this))
        }
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(HostBridge(), "host")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
    }

    inner class HostBridge {
        /**
         * Asynchronous RPC: returns immediately, the reply lands via
         * `onHostReply`.  It has to be async -- @JavascriptInterface methods
         * run on a binder thread and blocking one while Python computes would
         * freeze the UI for the length of the call.
         */
        @JavascriptInterface
        fun call(id: String, method: String, argsJson: String) {
            executor.execute {
                val reply = try {
                    val py = bridge ?: Python.getInstance()
                        .getModule("mylib.appbridge").also { bridge = it }
                    py.callAttr("call", method, argsJson).toString()
                } catch (e: Exception) {
                    // the same envelope Python uses for its own errors, so the
                    // page has exactly one error path rather than two
                    JSONObject().put("ok", false)
                        .put("error", e.toString()).toString()
                }
                // back to the UI thread: evaluateJavascript is not thread-safe
                runOnUiThread {
                    web.evaluateJavascript(
                        "window.onHostReply(${JSONObject.quote(id)}," +
                            "${JSONObject.quote(reply)})", null)
                }
            }
        }
    }
}
