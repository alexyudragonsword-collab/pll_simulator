plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.example.myapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.myapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        // track the version of the Python package you bundle; bump together
        versionName = "0.1.0"
        ndk {
            // arm64 for phones, x86_64 for the emulator.  Each ABI carries its
            // own CPython plus every binary wheel, so a third is tens of MB.
            // Drop x86_64 if you never use an emulator.
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

chaquopy {
    defaultConfig {
        // Must match the Python you run Gradle with (buildPython).  Nothing
        // checks the match; a mismatch surfaces much later as wheels pip
        // declines.  Which version you can pick is decided by your
        // dependencies -- see references/toolchain-and-versions.md.
        version = "3.10"

        pip {
            // Third-party binary packages come from Chaquopy's own index,
            // unpinned so pip takes the newest build it has for this Python.
            install("numpy")

            // Your own package.  Two supported shapes, and the wheels win
            // when they are present:
            //
            //   pysrc/mylib-X.Y.Z.tar.gz             -> interpreted build
            //   pysrc/mylib-X.Y.Z-cp310-...-*.whl    -> compiled build
            //
            // Produce the sdist from your project root with:
            //     python -m build --sdist --outdir android/app/pysrc .
            //
            // NOT install("../.."): a directory install makes the whole
            // repository an input of the pip task, and this Gradle project
            // sits inside that repository -- so every AGP task's output lands
            // inside the pip task's input and Gradle 8's validation fails the
            // build.  The sdist is the way around that, not a preference.
            //
            // Wheels are resolved by TAG via --find-links, never installed by
            // path: pip does no tag matching on a path, so the arm64 wheel
            // would be installed into the x86_64 variant too.
            //
            // And deliberately no --no-index: that option is global, and the
            // third-party installs above come from Chaquopy's index in this
            // same resolve.  Scoping your own package that way takes them
            // down with it.
            val pysrc = file("pysrc")
            val wheels = pysrc
                .listFiles { f -> f.name.matches(Regex("mylib-.*\\.whl")) }
                ?.toList() ?: emptyList()
            if (wheels.isNotEmpty()) {
                options("--find-links", pysrc.absolutePath)
                install("mylib")
            } else {
                val sdists = pysrc
                    .listFiles { f -> f.name.matches(Regex("mylib-.*\\.tar\\.gz")) }
                    ?.toList() ?: emptyList()
                // fail with the fix in the message: an empty pysrc/ is the
                // single most common way this build goes wrong, and "no
                // matching distribution" would not tell anyone what to do
                require(sdists.size == 1) {
                    "expected exactly one mylib sdist in android/app/pysrc/ " +
                        "(found ${sdists.size}); from the project root run: " +
                        "python -m build --sdist --outdir android/app/pysrc ."
                }
                install(sdists[0].absolutePath)
            }
        }
    }
}
