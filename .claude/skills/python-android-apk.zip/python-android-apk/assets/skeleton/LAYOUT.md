# Where each skeleton file goes

The files are stored flat here and copied into place. Two reasons, and the
second is why this is not just a packaging concession: an Android source tree
nests deep enough to hit archive path limits, and `MainActivity.kt`'s real
destination depends on **your** package name, so a fixed
`java/com/example/myapp/` would have been wrong for every reader anyway.

Copy into a project laid out like this, renaming `mylib` and
`com.example.myapp` throughout:

| file | goes to |
|---|---|
| `appbridge.py` | `src/mylib/appbridge.py` |
| `test_appbridge.py` | `tests/test_appbridge.py` |
| `settings.gradle.kts` | `android/settings.gradle.kts` |
| `build.gradle.kts` | `android/build.gradle.kts` |
| `app-build.gradle.kts` | `android/app/**build.gradle.kts**` (note the rename) |
| `AndroidManifest.xml` | `android/app/src/main/AndroidManifest.xml` |
| `MainActivity.kt` | `android/app/src/main/java/`**`<your/package/path>`**`/MainActivity.kt` |
| `index.html` | `android/app/src/main/assets/www/index.html` |

The Kotlin path must match the `package` line at the top of `MainActivity.kt`
and the `namespace` in `app-build.gradle.kts` — all three say
`com.example.myapp` as shipped, so change them together. Gradle will not find
the class if the directory and the package declaration disagree.

`android/app/pysrc/` is created by the build, not copied from here: it is
where your sdist or wheels land (see SKILL.md step 2).

Two paths are load-bearing beyond convention and should not be "tidied":

* `assets/www/` — `MainActivity` loads `file:///android_asset/www/index.html`.
  Anything under `src/main/assets/` is served from `file:///android_asset/`.
* `pysrc/` — the Gradle pip block reads that exact directory name.

As a one-liner, from the skill's `assets/skeleton/` directory, for a project
whose Kotlin package is `com.example.myapp`:

```bash
DEST=~/my-project
PKG=com/example/myapp
mkdir -p "$DEST"/{src/mylib,tests} \
         "$DEST"/android/app/src/main/{java/$PKG,assets/www}
cp appbridge.py        "$DEST/src/mylib/"
cp test_appbridge.py   "$DEST/tests/"
cp settings.gradle.kts build.gradle.kts "$DEST/android/"
cp app-build.gradle.kts "$DEST/android/app/build.gradle.kts"
cp AndroidManifest.xml "$DEST/android/app/src/main/"
cp MainActivity.kt     "$DEST/android/app/src/main/java/$PKG/"
cp index.html          "$DEST/android/app/src/main/assets/www/"
```
