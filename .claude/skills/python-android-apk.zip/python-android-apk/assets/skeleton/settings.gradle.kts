// Chaquopy lives at one URL that serves two different things: the Gradle
// plugin (pluginManagement) and the Python *package* repository its pip
// resolves numpy/scipy/... from (dependencyResolutionManagement).  Both
// blocks need it; omitting the second fails later and less obviously.
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven("https://chaquo.com/maven")
    }
}
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven("https://chaquo.com/maven")
    }
}
rootProject.name = "myapp"
include(":app")
