// Root build file.  The three versions here move together -- see
// references/toolchain-and-versions.md before bumping any of them, and in
// particular before bumping Chaquopy, which is what decides your Python
// version and therefore which third-party wheels exist at all.
plugins {
    id("com.android.application") version "8.1.4" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("com.chaquo.python") version "15.0.1" apply false
}
