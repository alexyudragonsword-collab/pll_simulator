# Which Python you get, and what moves with it

The order of reasoning here is the opposite of the usual one. You do not pick
a Python version and then install packages; **your heaviest binary dependency
picks the Python version**, and everything else follows from it. Getting this
backwards is the single most expensive mistake on this stack, because it is
discovered after the project exists.

## The feasibility gate

Chaquopy installs from two places:

* **pure-Python packages** — straight from PyPI, unchanged, any version pip
  can resolve. If your entire dependency tree is pure Python, skip to the
  next section; you are unconstrained.
* **packages with compiled extensions** — only from **Chaquopy's own
  repository** of Android wheels. numpy, scipy, pandas, pillow, cryptography
  and a few dozen others are there. Anything not there does not install, and
  no amount of Gradle configuration changes that.

So, before writing any code:

1. List every dependency with a C extension, transitively. `pip download` your
   package into an empty directory and look at what is not a `py3-none-any`
   wheel — that list is the constraint.
2. Check each against Chaquopy's package list
   (<https://chaquo.com/pypi-13.1/>, and the repository index its docs link)
   **for the Python version you intend to use**. Coverage differs per version;
   this is the step people skip.
3. Take the newest Python for which *all of them* exist. That is your version.

If something essential is missing, the honest options are: vendor a pure-Python
fallback, do without that feature on the phone, or build the wheel yourself
against Chaquopy's toolchain (real work — Chaquopy's `server/pypi` has the
recipe format). "It will probably be fine" is not one of them.

The concrete case this was written from: **scipy pinned the project to Python
3.10**, because Chaquopy's repository had no scipy wheel for anything newer
([chaquo/chaquopy#1237](https://github.com/chaquo/chaquopy/issues/1237)).
That single fact then determined the plugin version, the `buildPython`, and
the wheel tags of the compiled build. Check whether it still holds for you —
Chaquopy 17.x claims 3.10–3.14 support, which suggests the picture may have
moved, and re-checking costs one page load.

## The version set that moves together

| what | value used here | why it is that |
|---|---|---|
| Chaquopy `version` | `"3.10"` | decided by the gate above |
| `buildPython` / CI's `setup-python` | **the same** | must match Chaquopy's `version`. Nothing checks it; a mismatch surfaces much later as wheels pip declines |
| Chaquopy plugin | 15.0.1 | the newest line whose repository covered that Python at the time. It also fixes the CPython *target build* — 15.0.1 resolves `"3.10"` to `3.10.13-0`, which is what `android_wheel.py --target-version` needs |
| AGP `com.android.application` | 8.1.4 | Chaquopy 15.0.1 enforces a **minimum** of AGP 7.0.0 and **no maximum** (`Common.java: MIN_AGP_VERSION`, a one-sided check). Do not repeat the common claim that it supports a narrow AGP *range*; the source does not say that |
| Kotlin | 1.9.24 | pairs with AGP 8.1 |
| Gradle | 8.2 | pairs with that AGP |
| Java | 17 | what AGP 8.x requires |
| `compileSdk` | 34 | Chaquopy's own floor is `COMPILE_SDK_VERSION = 34` |
| `minSdk` | 24 | Chaquopy's floor is `MIN_SDK_VERSION = 21`; anything above that is your choice |
| `abiFilters` | `arm64-v8a`, `x86_64` | phones and the emulator. Every ABI carries a full copy of CPython and all binary wheels — this app measured **~40 MB per ABI**, so drop x86_64 if you never use an emulator |

Bumping the Chaquopy plugin is the one that cascades: it can change the Python
version, which changes wheel availability, which changes `buildPython` and any
compiled wheel tags. Re-run the feasibility gate when you do it.

## Where things are actually hosted

Two different URLs, easy to confuse when a network policy blocks one:

* `https://chaquo.com/maven` — the **Gradle plugin** *and* the **Python package
  repository** pip resolves binary wheels from. Declared in
  `settings.gradle.kts`, in both `pluginManagement` and
  `dependencyResolutionManagement`.
* `https://repo.maven.apache.org/maven2/com/chaquo/python/target/` — **Maven
  Central**, which is where the Android CPython headers and `libpythonX.Y.so`
  live (`com.chaquo.python:target`). This is what `scripts/android_wheel.py`
  downloads, so the compiled-wheel path keeps working in environments where
  chaquo.com is unreachable.

## One header caveat for the compiled path

On CPython **3.10** the C that Cython generates stays on the public API:
its `internal/pycore_frame.h` include sits behind
`PY_VERSION_HEX >= 0x030b00a6`. So the *patch* version of the headers is not
load-bearing and a near-enough target build works.

On **3.11+** that include is live, and the headers must be the exact target
build Chaquopy ships. If you move to 3.11 or newer, pass the matching
`--target-version` and verify an import on a device rather than trusting a
clean compile.

## Runtime environment, which no version pin covers

Set writable cache directories **before** `Python.start()` — `MainActivity`
does it with `Os.setenv`. matplotlib is the usual casualty: it builds a font
cache on first import and dies on a read-only config dir. `XDG_CACHE_HOME` and
`MPLCONFIGDIR` into `filesDir` costs two lines and saves a confusing crash
report from a device you may not have.
