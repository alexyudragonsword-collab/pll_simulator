# Failure modes, by the symptom you see first

Most of these do not point at their cause. Match the symptom, then read the
cause — theorising from the error message is how they each cost a day the
first time.

## Build-time

### "No matching distribution found for mylib"

`android/app/pysrc/` is empty, or holds an sdist for a different name than
the one `install()` asks for. Build the sdist:
`python -m build --sdist --outdir android/app/pysrc .`

The skeleton's Gradle config fails earlier and with that command in the
message, precisely because pip's own error does not tell anyone what to do.

### Gradle fails validating task inputs and outputs

`install("../..")` — a directory install makes the whole repository an input
of the pip task, and the Gradle project lives inside that repository, so every
Android task's output lands inside the pip task's input. Use an sdist.

### My change to the Python didn't do anything

The sdist in `pysrc/` is stale. Gradle cannot see through a tarball, so
nothing tells it to rebuild. Regenerate the sdist as part of every build —
put both commands in one script so they cannot separate.

### pip cannot find numpy / scipy after you touched the pip block

Someone added `--no-index` to scope the local install. It is a **global** pip
option and your binary dependencies come from Chaquopy's index in the same
resolve. Remove it; scope with `--find-links` instead.

### A dependency simply will not install

It has a C extension and Chaquopy's repository does not carry it for your
Python version. No Gradle setting fixes this — see the feasibility gate in
`toolchain-and-versions.md`. Check the *version-specific* list, not just the
package list.

### `cythonize -o` / `-X docstrings=False` errors, or silently does nothing

Neither is a real option. `-o` is not accepted by the `cythonize` frontend,
and `docstrings` is not an `-X` directive. The second is the dangerous one:
guessed flags can leave a build that completes while protecting nothing. The
real flag is `--no-docstrings`, on the `cython` command.

### The compile "succeeded" but nothing is compiled

A gcc/clang failure with stderr redirected leaves the `.py` in place, and
Python imports it in preference. Everything downstream looks normal.

After any compile step, **delete or move the `.py` and import again**. If it
still imports, you compiled nothing. `scripts/android_wheel.py` does this
check on its own output and refuses to finish otherwise.

## Runtime, on the device

### The app installs and immediately crashes on first compute

Usually a library writing to a read-only cache on import — matplotlib's font
cache is the classic. Set `MPLCONFIGDIR` and `XDG_CACHE_HOME` into `filesDir`
**before** `Python.start()`.

### `.so` loads on the emulator, not on the phone (or vice versa)

A wheel installed **by path** instead of by tag: pip does no ABI matching on a
path, so one architecture's wheel went into both variants. Use
`options("--find-links", dir)` + `install("mylib")`.

To confirm before shipping, read the ELF header of a `.so` in the wheel —
bytes 18–19 little-endian are `e_machine`: `0xB7` AArch64, `0x3E` x86-64,
`0x28` ARM.

### Everything is unresponsive but the screen looks normal

An overlay you toggled with `hidden` is still there. An author `display`
beats the UA's `[hidden] { display: none }`, so it is invisible and still
eating every tap. Add `#thing[hidden] { display: none }` explicitly.

The same symptom, different cause: an exception path that skipped
`busy.hidden = true`. Release the overlay in `finally`.

### A button in a drag/gesture area never fires

`setPointerCapture` moves the *click* target to the capturing element, so a
button underneath a pointer handler stops receiving clicks. Guard the capture:
`if (ev.target.closest("button")) return;`. This shipped once and survived a
release, because the button looks fine and the handler exists.

### The first control is under the status bar

Missing `viewport-fit=cover` and `env(safe-area-inset-*)` padding. Only
visible on a device with a notch or gesture bar.

### The app freezes for seconds on launch

The first bridge call pays the import of your whole stack. That is expected;
what is missing is a loading state. Show one until the first reply lands.

## CI and process

### The two APKs are identical

They ran back to back in one workspace and the second reused the first's pip
output. Nothing in the build log says so. Delete the sdist before the compiled
build, and gate both artifacts with `inspect_apk.py --native` / `--pure`.

### `mv: cannot stat 'a.apk b.apk'` in a workflow step

A **plain** YAML scalar folds onto one line and keeps the backslash, so bash
sees `\ ` — an escaped space — instead of a line continuation. Any multi-line
`run:` needs a block scalar (`run: |`).

### A step reports success from a piped command

`cmd | tail; echo $?` reports *tail's* status. Use `set -o pipefail`, or do
not pipe when the exit code is the thing you are about to report. This has
produced false "tests passed" claims.

### A test suite that skips instead of failing

GUI and device-adjacent suites often `skip` when their dependency is absent
rather than failing. A green run with everything skipped looks identical to a
green run that tested something. **Read the counts, not the colour** — and
after writing any check, break the thing it checks once and confirm it goes
red. A regex that matches nothing passes every assertion built on it.
