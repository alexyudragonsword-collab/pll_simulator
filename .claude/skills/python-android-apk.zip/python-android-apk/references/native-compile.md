# Compiling your Python into the APK

## Decide what you are buying first

Unpack any Chaquopy APK and you have your Python back: the payload holds
`.py` or `.pyc`, and `strings` on bytecode prints function names, line numbers
and whole docstrings. In the app this came from, an entire convention note
came out of a compiled module in plain prose.

`scripts/android_wheel.py` cythonises the subpackages you name and
cross-compiles them to `.so`. That replaces the above with machine code.

Be precise about the rest, because the compiled build invites a much bigger
claim than it earns:

* **WebView assets stay plain text.** Your page's JavaScript spells out every
  bridge method, its arguments and the whole UI flow.
* **Uncompiled modules still ship as bytecode**, with everything above intact.
* **Literal constants survive compilation.** They land in the constant pool.
  In a test build of the original app, three specific calibration values —
  `-122`, `4.8e9`, `1.92e7` — were each found *exactly once* by an eight-byte
  `struct.pack` search of the `.so`. Compiling the module that held them was
  therefore dropped from the plan: it would have been build surface bought for
  the appearance of protection.
* **Anything reachable at runtime is reachable.** A field the app displays can
  be read back by anyone who can run the app.

The honest summary, and a good sentence to hand whoever asked: it raises the
cost of reading your *algorithms* from "unzip and read" to "disassemble". It
is not a licence check, not data protection, and not obfuscation of anything
the UI shows.

## Running it

```bash
pip install cython build

# one wheel per ABI, dropped into android/app/pysrc/
python scripts/android_wheel.py --package mylib --compile core,solvers \
    --abi arm64-v8a --ndk "$ANDROID_NDK_HOME"
python scripts/android_wheel.py --package mylib --compile core,solvers \
    --abi x86_64 --ndk "$ANDROID_NDK_HOME"

gradle -p android :app:assembleDebug
```

`--package` is auto-detected when the project has exactly one importable
package. `--compile` takes subpackages or modules, dotted or slashed
(`core`, `core/backends`, `core.solve`), or the literal `all`.

**Delete any sdist from `pysrc/` first.** With both present, pip still has a
pure-Python distribution to resolve and you can get the interpreted build
under the impression it is compiled.

`--host` runs every step with your own compiler and no NDK. It is how to test
changes to the script: the cross build then differs only in which compiler and
headers are used.

## Choosing what to compile

`--compile` has no "everything" default, deliberately. The set you compile is
a claim that your test suite still passes with those `.py` files deleted, and
a default would make that claim on your behalf.

So make it true the same way the original did: build the wheel, install it,
delete the sources, run the full suite, and record the counts. For that app:
**31 of 85 modules** compiled, suite **564 passed / 13 skipped**, and the
headline result bit-identical to the interpreted build (`258.3043 fs` either
way). Size cost: **4.7 MB per ABI**, APK 84.21 → 87.33 MB.

A module that quietly falls back to its neighbouring `.py` looks exactly like
one that compiled correctly, which is why the script fails if any `.py`
survives beside a `.so` and why `inspect_apk.py --native` exists.

## How it works, in five steps

1. **Copy** the package to a work tree; the real source is never mutated.
2. **Fetch** Chaquopy's Android CPython from Maven Central
   (`com.chaquo.python:target`) — headers and `libpythonX.Y.so`. Only
   `Python.h` is needed; cythonised pure-Python modules pull in nothing else.
   Your binary dependencies stay as Chaquopy's prebuilt wheels; nothing here
   rebuilds numpy.
3. **Cythonise** each module with `cython -3 --no-docstrings --module-name
   <dotted.name>`. Both flags are load-bearing — see below.
4. **Compile** with the NDK's clang wrapper for the ABI triplet
   (`aarch64-linux-android21-clang`), `-shared -fPIC -O2
   -fvisibility=hidden`, linking libpython.
5. **Assemble** a wheel tagged `cp310-cp310-android_21_arm64_v8a`, reusing the
   project's real `dist-info` so METADATA never drifts from `pyproject.toml`.

Two flags decide whether this works at all:

* `--no-docstrings` is **not cosmetic**. Cython keeps docstrings by default
  and they are the most readable thing left in a compiled module. Note also
  that `-X docstrings=False` is *not* a real Cython option — it is a plausible
  guess that fails in a way that leaves a working build protecting nothing.
* `--module-name` must be the **full dotted path**, or the generated init
  function is named for the bare filename and the import fails at runtime.

## Verifying, not assuming

The script checks its own output: every named module produced a `.so`, and no
`.py` survived beside one. After the APK is built, check that too:

```bash
python scripts/inspect_apk.py app-debug.apk --package mylib --native core,solvers
```

And the check that actually proves it, on the built wheel or the installed
package:

```bash
strings path/to/module.so | grep "some docstring phrase"      # expect nothing
```

Run the same grep against an *uncompiled* module's `.pyc` first. If it does
not find the phrase there either, your grep is wrong and the negative result
means nothing — a control that costs one command and has caught exactly this
mistake before.

## What none of this proves

That the compiled module **loads on a device**. A clean cross-compile and a
correct-looking wheel are not a successful `import` on real hardware,
especially on Python 3.11+ where the generated C uses internal headers.
Sideload it and run one real calculation before calling it done.
