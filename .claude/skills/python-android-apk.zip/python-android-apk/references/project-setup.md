# Wiring it up: the bridge, the page, the Gradle config

Everything in `assets/skeleton/` is commented in place. This file is the part
that does not fit in a comment: why the pieces have these shapes, and which
constraints are not discoverable from the Chaquopy documentation.

## The bridge is one function, and that is the whole design

`appbridge.call(method, args_json) -> json_str`. Two strings in, one string
out, a registry of exposed functions behind it, and every failure returned in
the same envelope rather than raised.

Three things follow from that narrowness, and they are why it is worth
resisting the urge to expose objects across the boundary:

**It is testable on a laptop.** Every method the phone can reach is reachable
from pytest with no Android anywhere. That collapses the phone-only work to
"does the UI render this", which a person can check in a minute. A bridge
whose only test is "install the APK and tap around" is a bridge nobody tests,
and it will drift.

**One error path.** A bad method name, bad arguments and a genuine bug in your
library all come back as `{"ok": false, "error": ..., "traceback": ...}`, so
the page needs one branch. Keep the traceback: the alternative is debugging a
phone by guessing, and it costs nothing until something breaks.

**Kotlin stays inert.** Adding a feature is a Python function plus a render.
If a change ever seems to require touching Kotlin, look again — almost always
the logic wanted to be in Python, where the tests are.

## Threading: one lane, on purpose

`@JavascriptInterface` methods arrive on a binder thread, and blocking one
while Python computes freezes the UI for the length of the call. So the
bridge is asynchronous: `host.call(id, method, args)` returns immediately and
the answer comes back through `window.onHostReply(id, json)`. The page wraps
that in a promise so callers use ordinary `await`.

Behind it, a **single-threaded executor**. Two reasons, and the second is the
one people miss:

* Ordinary library code has no locking. One lane makes "one call at a time" a
  property of the app rather than a discipline every caller must maintain.
* The first call pays the import of your whole stack — several seconds on a
  phone for numpy + scipy + matplotlib. Serialising means paying it once,
  and the page must show a loading state until the first reply lands or the
  app looks broken on launch.

## Returning images

Render server-side and send a base64 PNG. There is no matplotlib in a WebView,
and shipping a plotting library in JavaScript to redraw what Python already
computed is a second implementation to keep in step.

One detail that costs an afternoon: do **not** save with
`bbox_inches="tight"`. It silently changes the figure's extent, so any pixel
coordinates you send alongside the image — an axes rectangle, cursor data,
hit regions — describe a different image than the one on screen. Set the
figure size instead. And close the figure after saving, or the phone leaks
one per call.

## The page

Plain HTML and JavaScript in `assets/www/`, loaded from
`file:///android_asset/`. No build step and no framework is a deliberate
choice: it keeps the diff readable, and the app's complexity where the tests
are.

Two rules that are not obvious and both cause the same bewildering symptom —
an invisible thing eating every tap:

* **`[hidden]` needs help.** An author `display: flex` beats the user agent's
  `[hidden] { display: none }`. Any element you toggle with `hidden` needs an
  explicit `#thing[hidden] { display: none }`. A busy overlay did exactly this
  in the app this came from.
* **Release the overlay in `finally`.** An early return that skips
  `busy.hidden = true` leaves the app permanently unresponsive with nothing
  on screen to explain it.

Also: phones have notches and gesture bars. `viewport-fit=cover` plus
`env(safe-area-inset-*)` padding, or your first control sits under the status
bar. This is only visible on a device.

## The Gradle config

`android/app/build.gradle.kts` carries the reasoning inline; the three
constraints worth repeating because each is a build failure:

* **The sdist, not `install("../..")`.** A directory install makes the whole
  repository an input of the pip task, and the Gradle project lives inside
  that repository — so every Android task's output lands inside the pip task's
  input, and Gradle 8's validation rejects the build.
* **Wheels by tag, never by path.** `options("--find-links", dir)` plus
  `install("mylib")` lets pip match the ABI. Installing a wheel by path skips
  tag matching entirely and puts the arm64 wheel in the x86_64 variant too.
* **No `--no-index`.** It is a global pip option, and your binary dependencies
  come from Chaquopy's index in the same resolve. Scoping your own package
  that way takes numpy and friends down with it.

Rebuild the sdist whenever your Python changes. Gradle cannot see through the
tarball, so a stale one silently ships old code — the most common "my fix did
nothing" on this stack.

## Permissions

The skeleton manifest declares **none**, and that is worth defending. An app
of this shape computes locally: the WebView loads `file:///android_asset`,
Python runs in-process, nothing is fetched. If a change wants `INTERNET`,
that should stop a review and be justified out loud, because it converts a
self-contained tool into one that can send whatever the user typed into it
somewhere else.

## CI

Build the APK on a **manual trigger**, not on every push, unless you have a
reason: a Chaquopy build downloads an SDK and several native wheels per ABI,
which is real runner time. Keep the fast Python tests on push, where they
belong, and let a human ask for the APK.

If you produce both an interpreted and a compiled APK in one run, they share
a workspace — so gate them with `scripts/inspect_apk.py` as shown in SKILL.md.
The failure mode is that the second build reuses the first's pip output and
both artifacts are the same APK under different names, and nothing in the log
would say so.
